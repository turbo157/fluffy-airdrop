export default function Footer() {
  return (
    <footer className="mt-8 md:mt-12 py-4 md:py-6 border-t border-gray-800 text-center text-gray-400 text-xs md:text-sm">
      <p>© 2025 Fluffy. All rights reserved.</p>
    </footer>
  )
}

