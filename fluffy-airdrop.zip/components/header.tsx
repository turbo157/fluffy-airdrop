import Link from "next/link"
import Image from "next/image"

export default function Header() {
  return (
    <header className="flex justify-between items-center py-4">
      <div className="flex items-center gap-2">
        <div className="relative w-10 h-10">
          <Image src="/images/Fluffy.png" alt="Fluffy Logo" fill className="object-contain" />
        </div>
        <span className="text-xl font-bold text-purple-800">Fluffy Airdrop</span>
      </div>

      <nav>
        <ul className="flex gap-6">
          <li>
            <Link href="#" className="text-purple-700 hover:text-purple-900 transition-colors">
              Home
            </Link>
          </li>
          <li>
            <Link href="#" className="text-purple-700 hover:text-purple-900 transition-colors">
              About
            </Link>
          </li>
          <li>
            <Link href="#" className="text-purple-700 hover:text-purple-900 transition-colors">
              FAQ
            </Link>
          </li>
        </ul>
      </nav>
    </header>
  )
}

