export default function ParticipationSteps() {
  return (
    <div className="mt-12 md:mt-20 mb-8 md:mb-12">
      <h2 className="text-2xl md:text-3xl font-bold text-white mb-8 md:mb-12">How to Participate</h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 max-w-4xl mx-auto">
        <Step number={1} title="Connect Wallet" description="Connect your crypto wallet" color="bg-blue-500" />
        <Step number={2} title="Claim Tokens" description="Claim your FLUFFY tokens" color="bg-green-500" />
        <Step
          number={3}
          title="Complete Tasks"
          description="Follow us on social media and complete simple tasks"
          color="bg-purple-500"
        />
      </div>
    </div>
  )
}

function Step({
  number,
  title,
  description,
  color,
}: {
  number: number
  title: string
  description: string
  color: string
}) {
  return (
    <div className="bg-[#1a2544] rounded-lg p-4 md:p-6">
      <div
        className={`${color} w-8 h-8 rounded-full flex items-center justify-center text-white font-bold mb-3 md:mb-4`}
      >
        {number}
      </div>
      <h3 className="text-white text-lg md:text-xl font-semibold mb-1 md:mb-2">{title}</h3>
      <p className="text-gray-400 text-sm md:text-base">{description}</p>
    </div>
  )
}

