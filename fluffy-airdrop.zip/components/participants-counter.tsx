"use client"

import { useEffect, useState } from "react"

export default function ParticipantsCounter() {
  const [count, setCount] = useState(23451)

  useEffect(() => {
    // Simulate new participants joining randomly
    const interval = setInterval(() => {
      // Random chance of new participant
      if (Math.random() > 0.7) {
        setCount((prevCount) => prevCount + 1)
      }
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return <div className="text-white text-2xl font-bold">{count.toLocaleString()}</div>
}

