"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Loader2 } from "lucide-react"

export default function AirdropForm() {
  const [walletAddress, setWalletAddress] = useState("")
  const [isConnecting, setIsConnecting] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [isClaiming, setIsClaiming] = useState(false)
  const [claimed, setClaimed] = useState(false)

  const connectWallet = async () => {
    setIsConnecting(true)

    // Simulate wallet connection
    setTimeout(() => {
      setIsConnecting(false)
      setIsConnected(true)
      setWalletAddress("0x1234...5678")
    }, 1500)
  }

  const claimAirdrop = async () => {
    setIsClaiming(true)

    // Simulate airdrop claim
    setTimeout(() => {
      setIsClaiming(false)
      setClaimed(true)
    }, 2000)
  }

  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      {!isConnected ? (
        <div>
          <p className="mb-4 text-gray-700">Connect your wallet to claim your Fluffy tokens</p>
          <Button onClick={connectWallet} className="w-full bg-purple-600 hover:bg-purple-700" disabled={isConnecting}>
            {isConnecting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Connecting...
              </>
            ) : (
              "Connect Wallet"
            )}
          </Button>
        </div>
      ) : !claimed ? (
        <div>
          <div className="mb-4">
            <p className="text-sm text-gray-500 mb-1">Connected Wallet</p>
            <Input value={walletAddress} readOnly className="bg-gray-50" />
          </div>
          <Button onClick={claimAirdrop} className="w-full bg-purple-600 hover:bg-purple-700" disabled={isClaiming}>
            {isClaiming ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Claiming...
              </>
            ) : (
              "Claim 100 FLUFFY Tokens"
            )}
          </Button>
        </div>
      ) : (
        <div className="text-center">
          <div className="mb-4 text-green-600 font-medium">🎉 Congratulations! 🎉</div>
          <p className="text-gray-700 mb-2">You have successfully claimed 100 FLUFFY tokens!</p>
          <p className="text-sm text-gray-500">Tokens have been sent to your wallet.</p>
        </div>
      )}
    </div>
  )
}

