"use client"
import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useMobile } from "@/hooks/use-mobile"

export default function Navigation() {
  const [aboutOpen, setAboutOpen] = useState(false)
  const isMobile = useMobile()

  return (
    <nav className="bg-[#0a1229] border-b border-gray-800">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-14 md:h-16">
          <div className="flex items-center space-x-2">
            <div className="flex items-center">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-blue-500 text-xl md:text-2xl font-extrabold tracking-tight">
                Fluffy
              </span>
            </div>
          </div>

          <div>
            <button
              onClick={() => setAboutOpen(true)}
              className="text-gray-300 hover:text-white transition-colors text-sm md:text-base"
            >
              About
            </button>
          </div>
        </div>
      </div>

      <Dialog open={aboutOpen} onOpenChange={setAboutOpen}>
        <DialogContent className="bg-[#1a2544] text-white border-gray-700 max-w-[350px] md:max-w-lg mx-auto">
          <DialogHeader>
            <DialogTitle className="text-xl md:text-2xl font-bold text-white">About Fluffy</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 mt-2 text-gray-300 text-xs md:text-sm">
            <div>
              Fluffy is a community-driven meme coin. Our mission is to create a fun and engaging cryptocurrency
              experience while building a strong community of holders.
            </div>

            <div>
              <h3 className="text-white font-semibold text-base md:text-lg">Tokenomics</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>Total Supply: 100,000,000,000 FLUFFY</li>
                <li>Airdrop Allocation: 75% of total supply</li>
                <li>Liquidity Pool: 10% (Locked for 1 year)</li>
                <li>Team: 15% (Vested over 12 months)</li>
              </ul>
            </div>

            <div>
              <h3 className="text-white font-semibold text-base md:text-lg">Features</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>0% Buy and Sell Tax</li>
                <li>Community Governance</li>
                <li>Regular Giveaways and Events</li>
                <li>NFT Integration (Coming Soon)</li>
              </ul>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </nav>
  )
}

