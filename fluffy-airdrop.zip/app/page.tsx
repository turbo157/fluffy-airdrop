"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import Navigation from "@/components/navigation"
import ParticipationSteps from "@/components/participation-steps"
import ReferralLink from "@/components/referral-link"
import Footer from "@/components/footer"
import { Loader2, LogOut } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { ToastProvider } from "@/components/ui/toast"
import { Toaster } from "@/components/ui/toaster"
import { useMobile } from "@/hooks/use-mobile"

export default function Home() {
  const [isWalletConnected, setIsWalletConnected] = useState(false)
  const [walletAddress, setWalletAddress] = useState("")
  const [isConnecting, setIsConnecting] = useState(false)
  const [lastClaimTime, setLastClaimTime] = useState<Date | null>(null)
  const [isClaiming, setIsClaiming] = useState(false)
  const [timeUntilNextClaim, setTimeUntilNextClaim] = useState<string | null>(null)
  const [fluffy, setFluffy] = useState(0)
  const [referralCode, setReferralCode] = useState("")
  const [referredUsers, setReferredUsers] = useState(0)
  const [dailyClaimCount, setDailyClaimCount] = useState(0)
  const [telegramFollowed, setTelegramFollowed] = useState(false)
  const [isVerifyingTelegram, setIsVerifyingTelegram] = useState(false)
  const [isDisconnecting, setIsDisconnecting] = useState(false)

  const isMobile = useMobile()

  // Generate a referral code if none exists
  useEffect(() => {
    const savedReferralCode = localStorage.getItem("referralCode")
    if (savedReferralCode) {
      setReferralCode(savedReferralCode)
    } else {
      const newCode = Math.random().toString(36).substring(2, 10)
      setReferralCode(newCode)
      localStorage.setItem("referralCode", newCode)
    }
  }, [])

  // Check if wallet was previously connected and load saved data
  useEffect(() => {
    const savedWalletStatus = localStorage.getItem("isWalletConnected")
    const savedWalletAddress = localStorage.getItem("walletAddress")
    const savedLastClaimTime = localStorage.getItem("lastClaimTime")
    const savedFluffy = localStorage.getItem("fluffy")
    const savedReferredUsers = localStorage.getItem("referredUsers")
    const savedDailyClaimCount = localStorage.getItem("dailyClaimCount")

    if (savedWalletStatus === "true" && savedWalletAddress) {
      setIsWalletConnected(true)
      setWalletAddress(savedWalletAddress)
    }

    if (savedLastClaimTime) {
      setLastClaimTime(new Date(savedLastClaimTime))
    }

    if (savedFluffy) {
      setFluffy(Number.parseInt(savedFluffy, 10))
    }

    if (savedReferredUsers) {
      setReferredUsers(Number.parseInt(savedReferredUsers, 10))
    }

    if (savedDailyClaimCount) {
      setDailyClaimCount(Number.parseInt(savedDailyClaimCount, 10))
    }

    if (localStorage.getItem("telegramFollowed") === "true") {
      setTelegramFollowed(true)
    }

    // Simulate random referrals coming in
    const referralInterval = setInterval(() => {
      // 5% chance of getting a new referral every 30 seconds if wallet is connected
      if (isWalletConnected && Math.random() < 0.05) {
        handleNewReferral()
      }
    }, 30000)

    return () => clearInterval(referralInterval)
  }, [isWalletConnected])

  // Update countdown timer
  useEffect(() => {
    if (!lastClaimTime) return

    const interval = setInterval(() => {
      const now = new Date()
      const nextClaimTime = new Date(lastClaimTime.getTime() + 24 * 60 * 60 * 1000)
      const diffMs = nextClaimTime.getTime() - now.getTime()

      if (diffMs <= 0) {
        setTimeUntilNextClaim(null)
        clearInterval(interval)
      } else {
        const hours = Math.floor(diffMs / (1000 * 60 * 60))
        const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60))
        const seconds = Math.floor((diffMs % (1000 * 60)) / 1000)
        setTimeUntilNextClaim(`${hours}h ${minutes}m ${seconds}s`)
      }
    }, 1000)

    return () => clearInterval(interval)
  }, [lastClaimTime])

  const connectWallet = async () => {
    setIsConnecting(true)

    // Simulate wallet connection with a delay
    setTimeout(() => {
      handleSuccessfulConnection()
    }, 1500)
  }

  const disconnectWallet = async () => {
    setIsDisconnecting(true)

    // Simulate wallet disconnection
    setTimeout(() => {
      // Clear wallet connection state
      setIsWalletConnected(false)
      setWalletAddress("")

      // Remove from localStorage
      localStorage.removeItem("isWalletConnected")
      localStorage.removeItem("walletAddress")

      setIsDisconnecting(false)

      toast({
        title: "Wallet Disconnected",
        description: "Your wallet has been disconnected successfully.",
      })
    }, 1000)
  }

  const handleSuccessfulConnection = () => {
    const randomAddress = `0x${Math.random().toString(36).substring(2, 10)}...${Math.random().toString(36).substring(2, 6)}`
    setWalletAddress(randomAddress)
    setIsWalletConnected(true)
    setIsConnecting(false)

    // Save to localStorage
    localStorage.setItem("isWalletConnected", "true")
    localStorage.setItem("walletAddress", randomAddress)

    // Check URL for referral code and process it
    const urlParams = new URLSearchParams(window.location.search)
    const refCode = urlParams.get("ref")
    if (refCode) {
      // This would normally validate the referral code on the server
      // For demo purposes, we'll just assume it's valid
      processReferralBonus(refCode)
    }

    toast({
      title: "Wallet Connected",
      description: `Successfully connected wallet: ${randomAddress}`,
    })
  }

  const processReferralBonus = (refCode: string) => {
    // In a real app, this would verify the referral code on the server
    // and credit the referrer with points

    // For demo purposes, we'll just show a toast
    toast({
      title: "Referral Detected",
      description: `You joined via a referral link. The referrer has received 300 FLUFFY!`,
    })
  }

  const handleNewReferral = () => {
    const newReferredUsers = referredUsers + 1
    const bonusAmount = 300
    const newFluffy = fluffy + bonusAmount

    setReferredUsers(newReferredUsers)
    setFluffy(newFluffy)

    localStorage.setItem("referredUsers", newReferredUsers.toString())
    localStorage.setItem("fluffy", newFluffy.toString())

    toast({
      title: "New Referral!",
      description: `Someone joined using your referral link! You earned ${bonusAmount} FLUFFY!`,
    })
  }

  const claimFluffy = async () => {
    // Check if 24 hours have passed since last claim
    if (lastClaimTime) {
      const now = new Date()
      const nextClaimTime = new Date(lastClaimTime.getTime() + 24 * 60 * 60 * 1000)

      if (now < nextClaimTime) {
        toast({
          title: "Claim not available yet",
          description: `You can claim again in ${timeUntilNextClaim}`,
          variant: "destructive",
        })
        return
      }
    }

    setIsClaiming(true)

    // Simulate claiming FLUFFY
    setTimeout(() => {
      const now = new Date()
      const claimAmount = 100
      const newDailyClaimCount = dailyClaimCount + 1
      const newFluffy = fluffy + claimAmount

      setLastClaimTime(now)
      setFluffy(newFluffy)
      setDailyClaimCount(newDailyClaimCount)
      setIsClaiming(false)

      // Save to localStorage
      localStorage.setItem("lastClaimTime", now.toISOString())
      localStorage.setItem("fluffy", newFluffy.toString())
      localStorage.setItem("dailyClaimCount", newDailyClaimCount.toString())

      toast({
        title: "Claim Successful!",
        description: `You've received ${claimAmount} FLUFFY! Come back in 24 hours to claim again.`,
      })
    }, 2000)
  }

  const followTelegram = async () => {
    if (telegramFollowed) return

    // Open Telegram bot in a new window
    const telegramWindow = window.open("https://t.me/FluffyDrop_bot", "_blank")

    setIsVerifyingTelegram(true)

    // Simulate verification process
    setTimeout(() => {
      // In a real app, this would be an actual API verification
      const followVerified = true // Simulate successful verification

      if (followVerified) {
        const bonusAmount = 200
        const newFluffy = fluffy + bonusAmount

        setFluffy(newFluffy)
        setTelegramFollowed(true)
        localStorage.setItem("fluffy", newFluffy.toString())
        localStorage.setItem("telegramFollowed", "true")

        toast({
          title: "Telegram Follow Verified!",
          description: `You've received ${bonusAmount} FLUFFY for following us on Telegram!`,
        })
      } else {
        toast({
          title: "Follow Not Verified",
          description: "Please make sure you join our Telegram group to receive FLUFFY.",
          variant: "destructive",
        })
      }

      setIsVerifyingTelegram(false)
    }, 3000)
  }

  return (
    <ToastProvider>
      <main className="min-h-screen bg-gradient-to-b from-[#0a1229] to-[#0f1b3c]">
        <Navigation />

        <div className="container mx-auto px-4 py-8 md:py-12 text-center">
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-2">Fluffy Airdrop is Live! 🎉</h1>
          <p className="text-gray-300 mb-6 md:mb-8 text-sm md:text-base">
            Claim your free FLUFFY now! Limited time offer for early adopters.
          </p>

          {isWalletConnected && (
            <div className="mb-4 text-gray-300">
              <div className="flex items-center justify-center gap-2">
                <span className="bg-[#1a2544] px-3 py-1 rounded-md text-xs md:text-sm">{walletAddress}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-gray-400 hover:text-white hover:bg-[#1a2544]"
                  onClick={disconnectWallet}
                  disabled={isDisconnecting}
                >
                  {isDisconnecting ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogOut className="h-4 w-4" />}
                </Button>
              </div>
              {fluffy > 0 && <div className="mt-2 text-green-400 font-semibold">{fluffy} FLUFFY</div>}
            </div>
          )}

          <div className="space-y-4 max-w-[180px] mx-auto mt-6 md:mt-8">
            {!isWalletConnected ? (
              <Button
                className="w-full bg-purple-600 hover:bg-purple-700 text-white py-4 md:py-6 text-base md:text-lg"
                variant="secondary"
                onClick={connectWallet}
                disabled={isConnecting}
              >
                {isConnecting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Connecting...
                  </>
                ) : (
                  "Connect Wallet"
                )}
              </Button>
            ) : timeUntilNextClaim ? (
              <div className="text-white text-base md:text-lg font-medium bg-[#1a2544] py-2 px-4 rounded-md">
                {timeUntilNextClaim}
              </div>
            ) : (
              <Button
                className="w-full bg-blue-500 hover:bg-blue-600 text-white py-4 md:py-6 text-base md:text-lg"
                onClick={claimFluffy}
                disabled={isClaiming}
              >
                {isClaiming ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Claiming...
                  </>
                ) : (
                  "Claim Now ⚡"
                )}
              </Button>
            )}
          </div>

          {isWalletConnected && (
            <ReferralLink
              referralCode={referralCode}
              referredUsers={referredUsers}
              followTelegram={followTelegram}
              telegramFollowed={telegramFollowed}
              isVerifyingTelegram={isVerifyingTelegram}
            />
          )}

          <ParticipationSteps />

          <Footer />
        </div>

        <Toaster />
      </main>
    </ToastProvider>
  )
}

